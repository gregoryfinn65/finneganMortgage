﻿
Partial Class MortgageMasterPage
    Inherits System.Web.UI.MasterPage
End Class

