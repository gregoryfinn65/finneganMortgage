﻿
Partial Class MNews
    Inherits System.Web.UI.Page

End Class
